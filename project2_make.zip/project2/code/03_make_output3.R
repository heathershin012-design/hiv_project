#! TO DO:
#!   add call to here::i_am

#! TO DO: 
#!   read random_numbers2 from output2 directory
random_numbers2 <- readRDS(
  #! fill in details
)

set.seed(3)
more_random_numbers <- rnorm(100)
random_numbers3 <- random_numbers2 + more_random_numbers

#! TO DO: 
#!   save random_numbers3 in output3 directory