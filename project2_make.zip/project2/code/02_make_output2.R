#! TO DO:
#!   add call to here::i_am

#! TO DO: 
#!   read random_numbers1 from output1 directory
random_numbers1 <- readRDS(
  #! fill in details
)

set.seed(2)
more_random_numbers <- rnorm(100)
random_numbers2 <- random_numbers1 + more_random_numbers

#! TO DO: 
#!   save random_numbers2 in output2 directory