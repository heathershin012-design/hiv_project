#! TO DO:
#!   add call to here::i_am

set.seed(1)
random_numbers1 <- rnorm(100)

#! TO DO: 
#!   save random_numbers1 in output1 directory